const ImageURLS = {
    a: require('./a.jpg'),
    b: require('./b.jpg'),
    c: require('./c.jpg'),
    d: require('./d.jpg'),
    ef: require('./e-f.jpg')
}

// const ImageURLS = new Map(); 

// ImageURLS.set('a', require('./a.jpg'));
// ImageURLS.set('b', require('./b.jpg'));
// ImageURLS.set('c', require('./c.jpg'));
// ImageURLS.set('d', require('./d.jpg'));
// ImageURLS.set('ef', require('./e-f.jpg'));