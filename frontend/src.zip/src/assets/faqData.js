import React from 'react'

const faqData = [
    {
      question: "What is React?",
      answer: "React is a JavaScript library for building user interfaces."
    },
    {
      question: "How do I install React?",
      answer: "You can install React using the create-react-app tool or by setting up a custom React project."
    },
    // Add more questions and answers here
  ];
  

export default faqData